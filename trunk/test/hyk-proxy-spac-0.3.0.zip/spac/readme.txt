spac plugin  Read Me
http://hyk-proxy.googlecode.com 

This file is part of hyk-proxy.                                   
                                                                  
hyk-proxy is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as           
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.                   
                                                                  
hyk-proxy is distributed in the hope that it will be useful,      
but WITHOUT ANY WARRANTY; without even the implied warranty of    
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     
GNU General Public License for more details.                      
                                                                  
You should have received a copy of the GNU General Public License 
along with hyk-proxy(client & server & plugin).  If not, see <http://www.gnu.org/licenses/>.

Dependencies
------------
You need to install hyk-proxy framework first.

INSTALL:
For GUI:
  Click tab penel 'Plugins', you can find a way to install it online.
For CLI:
  1. Download hyk-proxy-spac-[version].zip in <hyk-proxy>/plugins
  2. Unzip the downloaded package
  3. Restart hyk-proxy
 
