/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.hyk.proxy.gae.client.launch.gui;

/**
 *
 * @author Administrator
 */
public interface UICallback {

    public void callback(Object[] values);
}
