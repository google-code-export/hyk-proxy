/**
 * This file is part of the hyk-proxy project.
 * Copyright (c) 2010 Yin QiWen <yinqiwen@gmail.com>
 *
 * Description: RemoteObjectType.java 
 *
 * @author yinqiwen [ 2010-4-11 | ����11:12:25 ]
 *
 */
package com.hyk.proxy.gae.server.remote;

/**
 *
 */
public enum RemoteObjectType 
{
	FETCH,ACCOUNT, STAT, SERVICE_MANAGER
}
