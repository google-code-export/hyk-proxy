/**
 * This file is part of the hyk-proxy project.
 * Copyright (c) 2010 Yin QiWen <yinqiwen@gmail.com>
 *
 * Description: HttpHeaderValue.java 
 *
 * @author yinqiwen [ Feb 2, 2010 | 3:00:28 PM ]
 *
 */
package com.hyk.proxy.gae.common.http.header;

/**
 *
 */
public interface HttpHeaderValue
{

}
