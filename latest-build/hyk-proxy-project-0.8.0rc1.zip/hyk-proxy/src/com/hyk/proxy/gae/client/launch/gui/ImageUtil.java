/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.hyk.proxy.gae.client.launch.gui;

import javax.swing.ImageIcon;

/**
 *
 * @author Administrator
 */
public class ImageUtil
{
    public static final ImageIcon START = new javax.swing.ImageIcon(ImageUtil.class.getResource("/image/player_play.png"));
    public static final ImageIcon STOP = new javax.swing.ImageIcon(ImageUtil.class.getResource("/image/player_stop.png"));
    public static final ImageIcon CONFIG = new javax.swing.ImageIcon(ImageUtil.class.getResource("/image/configure.png"));
    public static final ImageIcon IDLE = new javax.swing.ImageIcon(ImageUtil.class.getResource("/image/idle.png"));
}
