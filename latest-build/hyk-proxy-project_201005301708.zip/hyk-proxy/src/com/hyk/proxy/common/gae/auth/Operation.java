/**
 * This file is part of the hyk-proxy project.
 * Copyright (c) 2010 Yin QiWen <yinqiwen@gmail.com>
 *
 * Description: Operation.java 
 *
 * @author yinqiwen [ 2010-4-10 | 08:17:03 am ]
 *
 */
package com.hyk.proxy.common.gae.auth;

/**
 *
 */
public enum Operation
{
	ADD, DELETE
}
