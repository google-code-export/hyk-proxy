package com.hyk.proxy.server.gae.rpc.remote;

public interface Reloadable
{
	public void init();
}
