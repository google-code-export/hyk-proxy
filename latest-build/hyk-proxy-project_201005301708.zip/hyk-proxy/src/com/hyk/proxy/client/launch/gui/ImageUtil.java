/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.hyk.proxy.client.launch.gui;

import javax.swing.ImageIcon;

/**
 *
 * @author Administrator
 */
public class ImageUtil
{
    public static final ImageIcon START = new javax.swing.ImageIcon(ImageUtil.class.getResource("/image/player_play.png"));
    public static final ImageIcon STOP = new javax.swing.ImageIcon(ImageUtil.class.getResource("/image/player_stop.png"));
    public static final ImageIcon CONFIG = new javax.swing.ImageIcon(ImageUtil.class.getResource("/image/configure.png"));
    //public static final ImageIcon IDLE = new javax.swing.ImageIcon(ImageUtil.class.getResource("/image/idle.png"));
    public static final ImageIcon ABOUT = new javax.swing.ImageIcon(ImageUtil.class.getResource("/image/about.png"));
    public static final ImageIcon HOME = new javax.swing.ImageIcon(ImageUtil.class.getResource("/image/gohome.png"));
    public static final ImageIcon PUBLISH = new javax.swing.ImageIcon(ImageUtil.class.getResource("/image/publish.png"));
    public static final ImageIcon UPDATE = new javax.swing.ImageIcon(ImageUtil.class.getResource("/image/Update.png"));
    public static final ImageIcon GAE = new javax.swing.ImageIcon(ImageUtil.class.getResource("/image/Google-AppEngine-16.png"));
}
